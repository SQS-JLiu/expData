#!/usr/bin/env python
#coding:utf-8
import subprocess,time
import os,platform
import shutil,sys

projectName = sys.argv[1]
src_dir = sys.argv[2]
sourceDir =r"E:\mutatorHome\experimentM\Apps"
mutantsDir = {}
outputApkDir = {}

passed_compilation_num = 0
failed_compilation_num = 0

list_files = []

def list_mutant_dir(path,list_name):
    for tempfile in os.listdir(path):
        file_path = os.path.join(path, tempfile)
        if os.path.isdir(file_path):
            list_mutant_dir(file_path, list_name)
        else:
            if os.path.isfile(file_path):
                list_name.append(file_path)
                # print file_path

def list_src_dir(path,list_name):  #传入存储的list_name
    for tempfile in os.listdir(path):
        file_path = os.path.join(path, tempfile)
        if os.path.isdir(file_path):
            list_src_dir(file_path, list_name)
        else:
            #  xxx/src/xxx.java
            if file_path.find(os.sep+"src"+os.sep) > 0 and file_path.endswith('.java'):
                list_name.append(file_path)
                # print file_path

def createMutantDir():
    list_mutant_dir(src_dir,list_files)
    pwd = os.getcwd()
    mutantDir = pwd+os.sep+"mutants"+os.sep+projectName
    for f in os.listdir(mutantDir):
        ff = mutantDir+os.sep+f
        if os.path.isdir(ff):
           mutantsDir[f] = ff
           buildDir = pwd+os.sep+"apks"+os.sep+projectName+os.sep+f
           outputApkDir[f] = buildDir
           if not os.path.exists(buildDir):
              os.makedirs(buildDir)

def genMutantProject():
    gradlewDir = getApkBuildDir(sourceDir + os.sep + projectName)
    pwd = os.getcwd()
    # change dir to execute command
    os.chdir(gradlewDir)
    for mutantDir,qualifiedDir in mutantsDir.items():
        apkFile = outputApkDir[mutantDir]+os.sep+"app-debug.apk"
        if os.path.exists(apkFile):
            continue
        print "*****mutant file : ", mutantDir
        try:
            for file in list_files:
                mutantFile = str(file).replace(src_dir,qualifiedDir)
                shutil.copy(mutantFile, file)
        except shutil.Error as err:
            # Ignore 255bit limit for long path files in Windows
            pass
        # execute "gradlew assembleDebug" to build apk
        result = run("gradlew assembleDebug")
        success = False
        # Linux
        # for res in result:
        #     if str(res).upper().find("BUILD SUCCESSFUL") > -1:
        #         success = True
        #         break
        # Windows
        if result.upper().find("BUILD SUCCESSFUL") > -1:
            success = True
        # move apk to mutant dir
        global passed_compilation_num,failed_compilation_num
        if success:
            passed_compilation_num = passed_compilation_num + 1
            moveApk2MutantDir(apkFile)
        else:
            failed_compilation_num = failed_compilation_num + 1
            print "Build apk failed !!!"
    # recover dir
    time.sleep(5)
    os.chdir(pwd)

def moveApk2MutantDir(mutantApkPath):
    apk_list = []
    get_apk_list(sourceDir + os.sep + projectName,apk_list)
    try:
        if len(apk_list) == 0:
            print "Warning , No Apk generated !!!"
        for apk_path in apk_list:
            # xxx/build/outputs/apk/xxx/xxx.apk
            if str(apk_path).find("build"+os.sep+"outputs"+os.sep+"apk") > -1:
                shutil.move(apk_path,mutantApkPath)
                print "** Move apk from: "+apk_path
    except:
        print "Apk already exists!!!"

def get_apk_list(path,apk_list):
    for tempfile in os.listdir(path):
        file_path = os.path.join(path, tempfile)
        if os.path.isdir(file_path):
            get_apk_list(file_path, apk_list)
        else:
            if file_path.endswith('.apk'):
                apk_list.append(file_path)

def getApkBuildDir(pro_dir):
    gradlew_list = []
    get_gradlew_list(pro_dir,gradlew_list)
    length = len(gradlew_list[0])
    gradlew_path = gradlew_list[0]
    for gradlew in gradlew_list:
        if length > len(gradlew):
            length = len(gradlew)
            gradlew_path = gradlew
    return str(gradlew_path).replace(os.sep+"gradlew","")

def get_gradlew_list(path,list_name):
    for tempfile in os.listdir(path):
        file_path = os.path.join(path, tempfile)
        if os.path.isdir(file_path):
            get_gradlew_list(file_path, list_name)
        else:
            if file_path.endswith('gradlew'):
                list_name.append(file_path)

def getMutantAndApkCount(path):
    # path = "E:\\mutatorHome\\experiments\\apk_output\\World-Weather"
    vtMutants = []
    vtAPKs = []
    list_mutant_dir(path, vtMutants)
    get_apk_list(path, vtAPKs)
    print  len(vtMutants)
    print  len(vtAPKs)
    return  vtMutants,vtAPKs

def run(cmd):
    ret = os.popen(cmd)
    result = ret.read()
    ret.close()
    return result

def run2(cmd):
    try:
        result = []
        if platform.system().upper() == "LINUX":
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, close_fds=True)
        elif platform.system().upper() == "WINDOWS":
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, close_fds=False)
        (stdout, stderr) = proc.communicate()
        output = stdout.split("\n")
        for line in output:
            if line == '':
                continue
            result.append(line)
        return str(result)
    except Exception as err:
        raise Exception("failed to execute command: %s, reason: %s" % (' '.join(cmd), err.message))

if __name__ == "__main__":
    print "Build starting..."
    createMutantDir()
    genMutantProject()
    if passed_compilation_num == 0 and failed_compilation_num == 0:
        print "*** Project %s was already built ***"%projectName
    print  "Passed compilation mutants: ",passed_compilation_num, "\nFailed compilation mutants: ",failed_compilation_num
    print  "Build finished..."
    sys.exit(0)
