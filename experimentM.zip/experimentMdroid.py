import subprocess
import platform,os
import datetime,time

mutants_dir = r"E:\mutatorHome\experimentM\mutants"

def subprocess_run(cmd):
    try:
        result = []
        proc = None
        if platform.system().upper() == "LINUX":
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, close_fds=True)
        elif platform.system().upper() == "WINDOWS":
            proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if proc is None:
            print "creating subprocess failed."
            return  result
        (stdout, stderr) = proc.communicate()
        #if stderr is not None:
        #    print stderr
        output = stdout.split(os.linesep)
        for line in output:
            tempLine = line.strip()
            if tempLine == '':
                continue
            result.append(tempLine)
        proc.terminate()
    except Exception as err:
        raise Exception("failed to execute command: %s, reason: %s" % (' '.join(cmd), err.message))
    return result

def os_run(cmd):
    ret = os.popen(cmd)
    result = ret.read()
    ret.close()
    return result

def read_mutation_project(app_project):
    readFile = open(app_project, "r")
    vtLines = readFile.readlines()
    vtProject = []
    for line in vtLines:
        if line.strip().startswith("#") or line.strip() == "":
            continue
        vtProject.append(line)
    readFile.close()
    return vtProject

def generateMutants():
    vtProject = read_mutation_project(r"E:\mutatorHome\experimentM\app_config.txt")
    # generating mutants
    for project in vtProject:
        project_name = project.split(" ")[1]
        print "Mutating "+project_name+"..."
        mutantsDir = mutants_dir+os.sep+project_name
        if not os.path.exists(mutantsDir):
            os.makedirs(mutantsDir)
        cmd = "java -jar MDroidPlus-1.0.0.jar libs4ast/ "+project.strip()+" . true"
        print "Executing Cmd: "+cmd
        starttime = datetime.datetime.now()
        vtResult = subprocess_run(cmd)
        endtime = datetime.datetime.now()
        seconds = (endtime - starttime).seconds
        outputFileDir = r"E:\mutatorHome\experimentM\reports.txt"
        outputFile = open(outputFileDir, "a")
        outputFile.write("----------------------------------------------------" + os.linesep)
        outputFile.write(
            "Mutation output (" + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "):" + os.linesep)
        outputFile.write("----------------------------------------------------" + os.linesep)
        outputFile.write("Project: "+project_name+". \tMutation Time: " + str(seconds) + os.linesep)
        outputFile.write("----------------------------------------------------")
        outputFile.close()
        print "Mutating "+project_name+" succeed !!!"
        # for line in vtResult:
        #     print line

def generateApk():
    vtProject = read_mutation_project(r"E:\mutatorHome\experimentM\build_app.txt")
    for project in vtProject:
        print "Compiling " + project.split(" ")[0] + "..."
        cmd = "python -u compileMdroid.py " + project
        print "Executing Cmd: " + cmd
        try:
           ret = subprocess.check_call(cmd, shell=True)
           if ret == 0:
               print "Task completed..."
        except subprocess.CalledProcessError:
           print "Task failed..."
        # vtResult = subprocess_run(cmd)
        # for line in vtResult:
        #     print line

def Main():
    generateMutants()
    generateApk()

if __name__ == "__main__":
    Main()
